create view pcd as
  select
    `pc`.`pname`    AS `pname`,
    `pc`.`orderid`  AS `orderid`,
    `pc`.`cname`    AS `cname`,
    `pc`.`areacode` AS `areacode`,
    `d`.`dname`     AS `dname`,
    `d`.`postcode`  AS `postcode`
  from (`employee`.`district` `d`
    join (select
            `p`.`pname`    AS `pname`,
            `p`.`orderid`  AS `orderid`,
            `c`.`cid`      AS `cid`,
            `c`.`pid`      AS `pid`,
            `c`.`cname`    AS `cname`,
            `c`.`areacode` AS `areacode`
          from (`employee`.`province` `p`
            join `employee`.`city` `c` on ((`p`.`pid` = `c`.`pid`)))) `pc` on ((`pc`.`cid` = `d`.`cid`)));

